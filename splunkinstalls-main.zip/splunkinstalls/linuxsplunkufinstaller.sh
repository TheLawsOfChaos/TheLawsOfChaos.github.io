#!/bin/bash

#init variables
#Create the path directly from the Splunk documentation 
export SPLUNK_HOME="/opt/splunkforwarder"
mkdir $SPLUNK_HOME
#create the DS variable
deployment_server="0.0.0.0:8089"
#wget creation
rpm_wget_command=""
deb_wget_command=""
tar_wget_command=""
#create account name
splunk_user="splunk"

install_redhat(){
    #download the installer
    $rpm_wget_command
    #uninstall previous versions if they exist
    rpm -e $(rpm -qa splunkforwarer) &> /dev/null
    rm -Rf /etc/init.d/splunk &> /dev/null
    rpm -i $(ls splunkforwarder) --nosignature
    if [[ -d "/opt/splunkforwarer" ]]
        then
            echo "Splunk is installed."
            rm -f $(ls splunkforwarder)
        else
            echo "Something went wrong."
            yum localinstall $(ls splunkforwarder) --nogpgcheck
            rm -f $(ls splunkforwarer)
            exit 0
    fi
}

install_debian(){
    #download the installer
    $deb_wget_command
    
    dpkg -l *splunkforwarder*
    dpkg -i $(ls splunkforwarder) &> /dev/null
    if [[ -d "/opt/splunkforwarer" ]]
        then
            echo "Splunk is installed."
            rm -f $(ls splunkforwarder)
        else
            echo "Something went wrong."
            dpkg -i $(ls splunkforwarder)
            rm -f $(ls splunkforwarer)
            exit 0
    fi
}

configure_ds_client_app(){
    ds_app_path="/opt/splunkforwader/etc/apps/a_dsclient_base"
    mkdir -p $ds_app_path/default
    touch $ds_app_path/default/deploymentclient.conf
    cat > $ds_app_path/default/deploymentclient.conf <<EOF
[deployment-client]

[target-broker:deploymentServer]
targetUri = $deployment_server
EOF

    chown -R splunk:splunk $ds_app_path
    echo "Deployment client configuration has been set."
}

detect_os(){
    #Find out what distro we are on
    # Detects which OS and if it is Linux then it will detect which Linux
    # Distribution.
    # from http://linuxmafia.com/faq/Admin/release-files.html
    #Code sheepishly taken, and modified by Brandon Sternfield for a Splunk UF Install
    
    OS=`uname -s`
    REV=`uname -r`
    MACH=`uname -m`
    
    if [ "${OS}" = "Linux" ] ; then
        KERNEL=`uname -r`
        if [ -f /etc/redhat-release ] ; then
            DIST='RedHat'
            PSUEDONAME=`cat /etc/redhat-release | sed s/.*\(// | sed s/\)//`
            REV=`cat /etc/redhat-release | sed s/.*release\ // | sed s/\ .*//`
            #commands go here
            echo "Installing on RedHat"
            install_redhat        
        elif [ -f /etc/debian_version ] ; then
            DIST="Debian `cat /etc/debian_version`"
            REV=""
            #commands go here
            echo "Installing on Debian"
            install_debian
        else 
            OSSTR="${OS} ${DIST} ${REV}(${PSUEDONAME} ${KERNEL} ${MACH})"
            echo ${OSSTR} " is not configured for install."
    fi
}


#init.main - Run it
detect_os
configure_ds_client_app
#boot start
chown -R $splunk_user:$splunk_user /opt/splunkforwader
admin_pw=`date | md5sum | awk '{ print $1 }'`
$SPLUNK_HOME/bin/splunk disable boot-start --accept-license --answer-yes --no-prompt &> /dev/null
$SPLUNK_HOME/bin/splunk enable-boot-start -user $splunk_user --accept-license --answer-yes --no-prompt --seed-passwd '$admin_pw' &> /dev/null
#start uf
systemctl start SplunkForwarder &> /dev/null
echo "Splunk has been started."
#config log access
setfacl -R -m u:$splunk_user:r-x /var/log



