 #!/bin/sh
 
 # --Variables that you must set -----
 
 # Remote Connection setup, this will be used to pass the root password
 SSHPASSWORD="..."

 # Populate this file with a list of hosts that this script should install to,
 # with one host per line. This must be specified in the form that should
 # be used for the ssh login, ie. username@host
 #
 # Example file contents:
 # splunkuser@10.20.13.4
 # splunkker@10.20.13.5
 HOSTS_FILE="/tmp/uf_script_install/splunk.install.list"
 
 # This should be a WGET command that was *carefully* copied from splunk.com!!
 # Sign into splunk.com and go to the download page, then look for the wget
 # link near the top of the page (once you have selected your platform)
 # copy and paste your wget command between the ""
 WGET_CMD="..."
 
 # Set the install file name to the name of the file that wget downloads
 # (the second argument to wget)
 INSTALL_FILE="..."
 
 # After installation, the forwarder will become a deployment client of this
 # host. Specify the host and management (not web) port of the deployment server
 # that will be managing these forwarder instances.
 DEPLOY_SERVER="...:8089"
 # Set the new Splunk admin password
 PASSWORD="password"
 
 # ----------- End of user settings -----------
 
 # create script to run remotely. Watch out for line wraps, esp. in the "set deploy-poll" line below.  
 # the remote script assumes that 'splunkuser' (the login account) has permissions to write to the
 # /opt directory (this is not generally the default in Linux)
 REMOTE_SCRIPT="
 echo "$SSHPassword" | sudo -S useradd -r -m splunk ;
 echo "$SSHPassword" | sudo -S passwd splunk --stdin ;
 echo "$SSHPassword" | sudo -S yum -y install wget unzip ;
 cd /tmp ;
 $WGET_CMD ;
 echo "$SSHPassword" | sudo -S tar -xzf $INSTALL_FILE -C /opt/ ;
 echo "$SSHPassword" | sudo -S /opt/splunkforwarder/bin/splunk status --accept-license ;
 echo "$SSHPassword" | sudo -S chown -R splunk:splunk /opt/splunkforwarder/ ;
 echo "$SSHPassword" | sudo -S /opt/splunkforwarder/bin/splunk enable boot-start -user splunk ;
 echo "$SSHPassword" | sudo -S /opt/splunkforwarder/bin/splunk set deploy-poll \"$DEPLOY_SERVER\" --accept-license --answer-yes --auto-ports --no-prompt -auth admin:changeme ;
 echo "$SSHPassword" | sudo -S /opt/splunkforwarder/bin/splunk edit user admin -password $PASSWORD -auth admin:changeme ;
 echo "$SSHPassword" | sudo -S /opt/splunkforwarder/bin/splunk restart
 "    
 echo "In 5 seconds, will run the following script on each remote host:"
 echo
 echo "===================="
 echo "$REMOTE_SCRIPT"
 echo "===================="
 echo
 sleep 5
 echo "Reading host logins from $HOSTS_FILE"
 echo
 echo "Starting."
 
 for DST in `cat "$HOSTS_FILE"`; do
   if [ -z "$DST" ]; then
     continue;
   fi
   echo "---------------------------"
   echo "Installing to $DST"
 
   # run script on remote host - you will be prompted for the password
   ssh "$DST" "$REMOTE_SCRIPT"
 
 done  
 echo "---------------------------"
 echo "Done"