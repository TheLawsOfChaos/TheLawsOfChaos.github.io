#!/bin/bash

#to disable web front end
#echo 'cd /opt/splunk/etc/system/local/
#echo "# For customers who want Splunk to run HTTPS
#[settings]
#startwebserver = 0" > web.conf
#chmod 755 /opt/splunk/etc/system/local/web.conf' > disableweb.sh

#chmod +x disableweb.sh
#sudo su -c ./disableweb.sh splunk
#rm disableweb.sh


