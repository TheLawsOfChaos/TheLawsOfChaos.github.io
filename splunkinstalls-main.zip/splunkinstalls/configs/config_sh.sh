#!/bin/bash

#./configs/config_https.sh

#echo 'read -p "What is the CM IP?: " cmIP
#splunk edit cluster-config -mode searchhead -manager_uri https://$cmIP:8089 -replication_port 9887 -secret key_for_me' > clustering.sh
#
#chmod +x clustering.sh
#sudo su -c ./clustering.sh splunk
#rm clustering.sh


cd ../apps/base_config
#Only keeps the apps we need
rm -r a_cm_base
rm -r a_deploymentclient
#a_indexes
#a_infra_inputs
#a_infra_outputs
#a_ingest_linux
rm -r a_ingest_win
#a_license_peer
#a_sh_base
rm -r a_uf_base
rm -r a_web_disable
#a_web_https

read -p "What is the License Manager IP? " licenseIP
sed -i "s/IP.of.license.manager/$licenseIP/g" a_license_peer/default/server.conf

read -p "What is the IDX Cluster Manager IP? " idxclusterIP
sed -i "s/IP.of.license.manager/$idxclusterIP/g" a_sh_base/local/server.conf

echo "Moving apps to /opt/splunk/apps"

echo "a_indexes"
sudo su -c "mv a_indexes /opt/splunk/etc/apps/" splunk
echo "a_infra_inputs"
sudo su -c "mv a_infra_inputs /opt/splunk/etc/apps/" splunk
echo "a_infra_outputs"
sudo su -c "mv a_infra_outputs /opt/splunk/etc/apps/" splunk
echo "a_ingest_linux"
sudo su -c "mv a_ingest_linux /opt/splunk/etc/apps/" splunk
echo "a_license_peer"
sudo su -c "mv a_license_peer /opt/splunk/etc/apps/" splunk
echo "a_sh_base"
sudo su -c "mv a_sh_base /opt/splunk/etc/apps/" splunk
echo "a_web_https"
sudo su -c "mv a_web_https /opt/splunk/etc/apps/" splunk

cd ..

echo "Splunk_TA_windows"
sudo su -c "mv Splunk_TA_windows /opt/splunk/etc/apps/" splunk
echo "Splunk_TA_nix"
sudo su -c "mv Splunk_TA_nix /opt/splunk/etc/apps/" splunk


sudo systemctl restart Splunkd