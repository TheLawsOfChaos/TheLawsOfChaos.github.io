#!/bin/bash

#./configs/config_https.sh
#
#echo 'read -p "What is the secret?: " secretKey
#read -p "What is the cluster label?: " clusterLabel
#read -p "What is the search factor?[ex. 3]: " searchFactor
#read -p "What is the replication factor?[ex. 3]: " replicationFactor
#echo "Enabling this server as a Cluster manager with the secret of $secretKey"
#/opt/splunk/bin/splunk edit cluster-config -mode manager -replication_factor $replicationFactor -search_factor $searchFactor -secret $secretKey -cluster_label $clusterLabel' > clustermanagerenable.sh
#
#chmod +x clustermanagerenable.sh
#sudo su -c ./clustermanagerenable.sh splunk
#rm clustermanagerenable.sh


cd ../apps/base_config
#Only keeps the apps we need
#a_cm_base
rm -r a_deploymentclient
#a_idx_cluster
#a_indexes
#a_infra_inputs
#a_infra_outputs
#a_ingest_linux
rm -r a_ingest_win
#a_license_peer
rm -r a_sh_base
rm -r a_uf_base
#a_web_disable
#a_web_https

read -p "What is the License Manager IP? " licenseIP
sed -i "s/IP.of.license.manager/$licenseIP/g" a_license_peer/default/server.conf

echo "Moving apps to /opt/splunk/etc/manager-apps/"
echo "a_web_disable"
sudo su -c "mv a_web_disable /opt/splunk/etc/manager-apps/" splunk
echo "a_idx_cluster"
sudo su -c "mv a_idx_cluster /opt/splunk/etc/manager-apps/" splunk
echo "a_license_peer"
sudo su -c "mv a_license_peer /opt/splunk/etc/manager-apps/" splunk
echo "a_infra_inputs"
sudo su -c "cp -r a_infra_inputs /opt/splunk/etc/manager-apps/" splunk
echo "a_infra_outputs"
sudo su -c "cp -r a_infra_outputs /opt/splunk/etc/manager-apps/" splunk
echo "a_ingest_linux"
sudo su -c "cp -r a_ingest_linux /opt/splunk/etc/manager-apps/" splunk

echo "Moving apps to /opt/splunk/apps"
echo "a_infra_inputs"
sudo su -c "mv a_infra_inputs /opt/splunk/etc/apps/" splunk
echo "a_infra_outputs"
sudo su -c "mv a_infra_outputs /opt/splunk/etc/apps/" splunk
echo "a_ingest_linux"
sudo su -c "mv a_ingest_linux /opt/splunk/etc/apps/" splunk
echo "a_web_https"
sudo su -c "mv a_web_https /opt/splunk/etc/apps/" splunk

echo "Restarting splunkd"
sudo systemctl restart Splunkd



