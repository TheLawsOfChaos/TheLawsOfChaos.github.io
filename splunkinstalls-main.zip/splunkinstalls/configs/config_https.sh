#!/bin/bash

#to disable web front end
#echo 'echo "Enabling HTTPS
#echo "# For customers who want Splunk to run HTTPS
#[settings]
#enableSplunkWebSSL = true" > /opt/splunk/etc/system/local/web.conf
#chmod 755 /opt/splunk/etc/system/local/web.conf' > enableHTTPS.sh
#
#chmod +x enableHTTPS.sh
#sudo su -c ./enableHTTPS.sh splunk
#rm enableHTTPS.sh
#
#
#
#anything with web active isn't an indexer, so disable indexing
#echo 'echo "Moving the no index app over
#mv ../apps/base_config/a_no_idx /opt/splunk/etc/apps/
#chmod -R 755 /opt/splunk/etc/apps/a_no_idx' > disableIndexing.sh
#
#chmod +x disableIndexing.sh
#sudo su -c ./disableIndexing.sh splunk
#rm disableIndexing.sh

sudo systemctl restart Splunkd