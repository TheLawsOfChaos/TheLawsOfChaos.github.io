#!/bin/bash

#test grub to ensure our option is there
echo "Dumping out grub to verify THP is disabled"
sudo cat /proc/cmdline

#look for always madvise [never]
echo "If we don't see 'always madvise [never]' we messed up"
sudo cat /sys/kernel/mm/transparent_hugepage/enabled

#what are we installing?
read -p "What will this be? [CM/DS/IDX/SH]" serverType

config="0"
case $serverType in

    [cC][mM] )
        echo "CM chosen"; config="config_cm.sh"
        ;;

    [dD][sS] )
        echo "DS chosen"; config="config_ds.sh"
        ;;
    
    [iI][dD][xX] )
        echo "IDX chosen"; config="config_idx.sh"
        ;;
    
    [sS][hH] )
        echo "SH chosen"; config="config_sh.sh"
        ;;
    
    *) 
        echo "Unknown"
        ;;
esac

if [ $config == "0" ]
then   
    echo "No server role picked, install it yourself."
else
    ./configs/$config
fi