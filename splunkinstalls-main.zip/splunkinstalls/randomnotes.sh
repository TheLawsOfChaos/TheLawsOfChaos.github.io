#!/bin/bash
#add license - from LM
splunk add licenses <path_to_license>/<license_name>.xml 
#list licenses - from LM
splunk list licenses
#Check license peers  - from LM
splunk list licenser-peers | grep label


#check indexer peers - from CM
splunk list cluster-peers | grep label

#check if the SH is attached so the IDX cluster - from SH
splunk list manager

#check the current server roles for the splunk instance
# | rest /services/server/info | fields server_roles

#swap license to a license manager
splunkedit licenser-localpeer –manager_uri https://{LM:Mport}

#add this to /etc/systemd/system/Splunkd.service without comments
#LimitNOFILE=64000
#LimitNPROC=16000
#LimitDATA=8589934592
#LimitFSIZE=infinity
#TasksMax=8192

#then have to reload
#systemctl daemon-reload

#mkdir .ssh && touch .ssh/authorized_keys
#type $env:USERPROFILE\.ssh\id_rsa.pub | ssh losty@192.168.51.100 "cat >> .ssh/authorized_keys"
