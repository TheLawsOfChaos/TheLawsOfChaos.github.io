#!/bin/bash

#Total start and Splunk install
#Written with blood, sweat, and a lot of tears by
#       Brandon Sternfield
#       github: https://github.com/TheLawsOfChaos/splunkinstalls

#init directory variable
SPLUNK_HOME="/opt/splunk"

#create the splunk user
echo "Creating the splunk user now"
#http://docs.splunk.com/Documentation/Splunk/latest/Installation/RunSplunkasadifferentornon-rootuser
sudo useradd splunk
sudo groupadd splunk

#ensure splunk user can read /var/log for ingest
sudo setfacl -R -m u:splunk:r-x /var/log

echo "Enable firewalld"
sudo systemctl enable firewalld
echo "Start firewalld"
sudo systemctl start firewalld
#https://docs.splunk.com/Documentation/Splunk/9.1.0/InheritedDeployment/Ports
echo "Firewall 8000"
sudo firewall-cmd --zone=public --add-port=8000/tcp --permanent #web
echo "Firewall 8065"
sudo firewall-cmd --zone=public --add-port=8065/tcp --permanent #appkey
echo "Firewall 8080"
sudo firewall-cmd --zone=public --add-port=8080/tcp --permanent #idxclusterrep
echo "Firewall 8081"
sudo firewall-cmd --zone=public --add-port=8081/tcp --permanent #shcluster
echo "Firewall 8088"
sudo firewall-cmd --zone=public --add-port=8088/tcp --permanent #HEC
echo "Firewall 8089"
sudo firewall-cmd --zone=public --add-port=8089/tcp --permanent #splunkd
echo "Firewall 8181"
sudo firewall-cmd --zone=public --add-port=8181/tcp --permanent #shclusterrep
echo "Firewall 8191"
sudo firewall-cmd --zone=public --add-port=8191/tcp --permanent #kvstore
echo "Firewall 9887"
sudo firewall-cmd --zone=public --add-port=9887/tcp --permanent #idxcluster
echo "Firewall 9997"
sudo firewall-cmd --zone=public --add-port=9997/tcp --permanent #splunktcplisten
echo "Firewall 9998"
sudo firewall-cmd --zone=public --add-port=9998/tcp --permanent #splunkssllisten
echo "Reloading firewalld"
sudo firewall-cmd --reload

echo "Download Splunk"
#init splunk installer variable
SPLUNK_INSTA="splunk-9.1.0.2-b6436b649711-Linux-x86_64.tgz"
#download current splunk installer as of 25/08/2023
wget -O $SPLUNK_INSTA "https://download.splunk.com/products/splunk/releases/9.1.0.2/linux/splunk-9.1.0.2-b6436b649711-Linux-x86_64.tgz"
echo "Installing Splunk"
sudo tar xvzf $SPLUNK_INSTA -C /opt

#ensuring the splunk user owns the entire splunk directory
sudo chown -R splunk:splunk $SPLUNK_HOME

#dumping commands to a file to run it as the splunk user
echo "echo 'starting splunk'
/opt/splunk/bin/splunk start --accept-license --answer-yes
echo 'stopping splunk'
/opt/splunk/bin/splunk stop" >> startstopsplunk.sh
chmod +x startstopsplunk.sh
sudo su -c ./startstopsplunk.sh splunk
rm startstopsplunk.sh

echo "Start splunk on bootup as the splunk user"
sudo /opt/splunk/bin/splunk enable boot-start -systemd-managed 1 -user splunk -group splunk

#set ulimits
echo "setting ulimits"
sudo ulimit -n 64000
sudo ulimit -u 16000
sudo ulimit -f unlimited
sudo ulimit -d 4000000 #(4GB, change based on needs)

#for /etc/systemd/system/Splunkd.service
#LimitNOFILE=64000
#LimitNPROC=16000
#LimitDATA=8589934592
#LimitFSIZE=infinity
#TasksMax=8192

#disable THP
#verify the location of the grub file first so this works
echo "editing GRUB to disable THP"
sudo sed -i 's/rhgb/rhgb transparent_hugepage=never/' /etc/default/grub 
cat /etc/default/grub

#rebuild grub
echo "rebuilding grub"
sudo grub2-mkconfig -o /boot/grub2/grub.cfg

echo "run postinstall.sh after reboot"

#reboot to take affect
echo "Rebooting now."
sudo shutdown -r now