### As the entire infrastructure will be on various bare metal machines running hyper-visors that have other tasks, ignoring their existence. All work will be completed inside VMs, so only they will be named.

<Role><Location><##>

Examples:
SH-HQ-01
IDX-HQ-01
DS-HQ-01
LM-HQ-01

Real Names:
* SH-HQ-01
    00:00:00:00:10:00
    192.168.51.100	
* IDX-HQ-01
    00:00:00:00:20:00
    192.168.51.110	
* IDX-HQ-02
    00:00:00:00:20:01
    192.168.51.111
* IDX-HQ-03
    00:00:00:00:20:02
    192.168.51.112	
* CM-HQ-01
    00:00:00:00:30:00
    192.168.51.120	
* DS-HQ-01
    00:00:00:00:40:00
    192.168.51.130
* LM-HQ-01